# Chapitre IV-planification

## Contenu du chapitre


- [12-backlog-modules-fonctionnels](./12-backlog-modules-fonctionnels.md) - ✅ 4. Organiser le backlog de migration par modules fonctionnels
- [13-versionnement-intelligent](./13-versionnement-intelligent.md) - 35-versionnement-intelligent
