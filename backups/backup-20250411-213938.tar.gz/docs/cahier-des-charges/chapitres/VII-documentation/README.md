# Chapitre VII-documentation

## Contenu du chapitre


- [19-journal-modifications](./19-journal-modifications.md) - Journal des modifications
