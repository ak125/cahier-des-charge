# Cahier des Charges - Migration PHP vers NestJS/Remix

Ce dépôt contient la documentation et les outils de gestion du cahier des charges pour la migration d'une application PHP vers NestJS/Remix.

## Structure du projet

- `/cahier-des-charges/` - Documentation principale du cahier des charges
  - `/docs/` - Documents généraux (architecture, stratégie, etc.)
  - `/audits/` - Analyse détaillée des fichiers existants
  - `/backlogs/` - Backlogs des tâches à effectuer
  - `/impact-graphs/` - Graphes d'impact et de dépendance
  - `/rapports/` - Rapports générés

- `/scripts/` - Scripts d'automatisation
  - `/verifiers/` - Scripts de vérification
  - `/utils/` - Utilitaires
  - `/templates/` - Templates pour la génération de fichiers

- `/agents/` - Agents IA d'analyse et de génération
- `/tools/` - Outils divers
- `/rules/` - Règles de configuration
- `/logs/` - Journaux d'exécution
- `/dist/` - Fichiers générés (HTML, PDF, etc.)

## Commandes principales

```bash
# Démarrer le menu interactif
./manage-cahier.sh

# Vérifier le cahier des charges
./scripts/verify-cahier.sh

# Générer la vue HTML
./scripts/render-html.sh

# Exécuter tous les scripts en dry-run
./scripts/dry-run-all.sh
```

## Maintenance

Ce projet est maintenu automatiquement par un système d'agents IA.
