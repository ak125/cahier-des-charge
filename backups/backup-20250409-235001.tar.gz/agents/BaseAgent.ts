import * as fs from 'fs/promises';
import * as path from 'path';

export interface AuditSection {
  id: string;
  title: string;
  content: string;
  type: string;
  severity?: 'info' | 'warning' | 'critical';
  source?: string;
}

export abstract class BaseAgent {
  protected filePath: string;
  protected fileContent: string = '';
  protected sections: AuditSection[] = [];

  constructor(filePath: string) {
    this.filePath = filePath;
  }

  /**
   * Charge le contenu du fichier PHP
   */
  public async loadFile(): Promise<void> {
    try {
      this.fileContent = await fs.readFile(this.filePath, 'utf8');
    } catch (error) {
      throw new Error(`Erreur lors du chargement du fichier: ${error.message}`);
    }
  }

  /**
   * Sauvegarde les sections d'audit générées
   */
  public async saveSections(): Promise<void> {
    const baseFilename = path.basename(this.filePath);
    const dirPath = path.dirname(this.filePath);
    const outputPath = path.join(dirPath, `${baseFilename}.audit.sections.json`);
    
    try {
      // Vérifier si le fichier existe déjà
      let existingSections: AuditSection[] = [];
      try {
        const existingData = await fs.readFile(outputPath, 'utf8');
        existingSections = JSON.parse(existingData);
      } catch (error) {
        // Le fichier n'existe pas encore, on continue
      }
      
      // Fusionner ou ajouter les nouvelles sections
      const updatedSections = [...existingSections];
      
      for (const newSection of this.sections) {
        const existingIndex = updatedSections.findIndex(s => s.id === newSection.id);
        if (existingIndex !== -1) {
          updatedSections[existingIndex] = newSection;
        } else {
          updatedSections.push(newSection);
        }
      }
      
      // Écrire le fichier mis à jour
      await fs.writeFile(outputPath, JSON.stringify(updatedSections, null, 2), 'utf8');
      console.log(`✅ Sections d'audit enregistrées dans ${outputPath}`);
    } catch (error) {
      throw new Error(`Erreur lors de la sauvegarde des sections: ${error.message}`);
    }
  }

  /**
   * Ajoute une section au rapport d'audit
   */
  protected addSection(
    id: string, 
    title: string, 
    content: string, 
    type: string,
    severity: 'info' | 'warning' | 'critical' = 'info'
  ): void {
    this.sections.push({
      id,
      title,
      content,
      type,
      severity,
      source: this.constructor.name
    });
  }

  /**
   * Méthode principale d'analyse à implémenter par chaque agent
   */
  public abstract analyze(): Promise<void>;

  /**
   * Exécute l'agent complet
   */
  public async process(): Promise<void> {
    try {
      await this.loadFile();
      await this.analyze();
      await this.saveSections();
    } catch (error) {
      console.error(`❌ Erreur lors du traitement: ${error.message}`);
      throw error;
    }
  }
}
