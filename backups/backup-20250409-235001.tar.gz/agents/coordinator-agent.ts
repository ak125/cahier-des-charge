import * as fs from 'fs/promises';
import * as path from 'path';
import { BusinessAgent } from './BusinessAgent';
import { StructureAgent } from './StructureAgent';
import { DataAgent } from './DataAgent';
import { DependencyAgent } from './DependencyAgent';
import { QualityAgent } from './QualityAgent';
import { StrategyAgent } from './StrategyAgent';
import { AssemblerAgent } from './AssemblerAgent';

/**
 * Configuration pour le CoordinatorAgent
 */
interface CoordinatorConfig {
  phpFilePath: string;
  outputDir?: string;
  agentsToRun?: ('business' | 'structure' | 'data' | 'dependency' | 'quality' | 'strategy' | 'assembler')[];
  parallel?: boolean;
  forceRerun?: boolean;
  hooks?: {
    beforeAgent?: (agentName: string) => Promise<void>;
    afterAgent?: (agentName: string) => Promise<void>;
    onError?: (agentName: string, error: Error) => Promise<void>;
    onComplete?: () => Promise<void>;
  };
}

/**
 * Résultat d'exécution d'un agent
 */
interface AgentExecutionResult {
  agentName: string;
  success: boolean;
  error?: Error;
  executionTime: number;
}

/**
 * Agent coordinateur responsable d'orchestrer l'exécution
 * des différents agents d'analyse dans le bon ordre
 */
export class CoordinatorAgent {
  private config: CoordinatorConfig;
  private results: AgentExecutionResult[] = [];
  private startTime: number = 0;

  constructor(config: CoordinatorConfig) {
    // Configuration par défaut
    this.config = {
      outputDir: path.dirname(config.phpFilePath),
      agentsToRun: ['business', 'structure', 'data', 'dependency', 'quality', 'strategy', 'assembler'],
      parallel: false,
      forceRerun: false,
      hooks: {},
      ...config
    };
  }

  /**
   * Vérifie si le fichier PHP existe
   */
  private async validateFile(): Promise<void> {
    try {
      await fs.access(this.config.phpFilePath);
    } catch (error) {
      throw new Error(`Le fichier PHP n'existe pas: ${this.config.phpFilePath}`);
    }
  }

  /**
   * Crée le répertoire de sortie s'il n'existe pas
   */
  private async ensureOutputDirectory(): Promise<void> {
    try {
      await fs.mkdir(this.config.outputDir, { recursive: true });
    } catch (error) {
      throw new Error(`Impossible de créer le répertoire de sortie: ${error.message}`);
    }
  }

  /**
   * Initialise le fichier de sections d'audit s'il n'existe pas
   */
  private async initializeAuditSections(): Promise<void> {
    const baseFilename = path.basename(this.config.phpFilePath);
    const sectionsPath = path.join(this.config.outputDir, `${baseFilename}.audit.sections.json`);

    try {
      // Vérifier si le fichier existe déjà
      await fs.access(sectionsPath);
      
      // Si on force la réexécution, réinitialiser le fichier
      if (this.config.forceRerun) {
        await fs.writeFile(sectionsPath, '[]', 'utf8');
        console.log(`Fichier de sections réinitialisé: ${sectionsPath}`);
      } else {
        console.log(`Fichier de sections existant: ${sectionsPath}`);
      }
    } catch (error) {
      // Le fichier n'existe pas, le créer
      await fs.writeFile(sectionsPath, '[]', 'utf8');
      console.log(`Nouveau fichier de sections créé: ${sectionsPath}`);
    }
  }

  /**
   * Exécute un agent spécifique et gère les hooks associés
   */
  private async executeAgent(agentType: string): Promise<AgentExecutionResult> {
    console.log(`🔄 Exécution de l'agent: ${agentType}`);
    const startTime = Date.now();
    
    // Hook avant l'exécution de l'agent
    if (this.config.hooks?.beforeAgent) {
      await this.config.hooks.beforeAgent(agentType);
    }
    
    try {
      let agent;
      switch (agentType) {
        case 'business':
          agent = new BusinessAgent(this.config.phpFilePath);
          break;
        case 'structure':
          agent = new StructureAgent(this.config.phpFilePath);
          break;
        case 'data':
          agent = new DataAgent(this.config.phpFilePath);
          break;
        case 'dependency':
          agent = new DependencyAgent(this.config.phpFilePath);
          break;
        case 'quality':
          agent = new QualityAgent(this.config.phpFilePath);
          break;
        case 'strategy':
          agent = new StrategyAgent(this.config.phpFilePath);
          break;
        case 'assembler':
          agent = new AssemblerAgent(this.config.phpFilePath);
          break;
        default:
          throw new Error(`Agent inconnu: ${agentType}`);
      }
      
      await agent.process();
      
      const executionTime = Date.now() - startTime;
      console.log(`✅ Agent ${agentType} terminé en ${executionTime}ms`);
      
      // Hook après l'exécution réussie de l'agent
      if (this.config.hooks?.afterAgent) {
        await this.config.hooks.afterAgent(agentType);
      }
      
      return {
        agentName: agentType,
        success: true,
        executionTime
      };
    } catch (error) {
      const executionTime = Date.now() - startTime;
      console.error(`❌ Erreur lors de l'exécution de l'agent ${agentType}: ${error.message}`);
      
      // Hook en cas d'erreur
      if (this.config.hooks?.onError) {
        await this.config.hooks.onError(agentType, error);
      }
      
      return {
        agentName: agentType,
        success: false,
        error,
        executionTime
      };
    }
  }

  /**
   * Exécute tous les agents en série
   */
  private async executeSerially(): Promise<void> {
    for (const agentType of this.config.agentsToRun) {
      const result = await this.executeAgent(agentType);
      this.results.push(result);
      
      // Si un agent échoue et que c'est l'assembleur, on s'arrête
      if (!result.success && agentType === 'assembler') {
        throw new Error(`L'agent assembleur a échoué. Arrêt du processus.`);
      }
    }
  }

  /**
   * Exécute les agents en parallèle, sauf l'assembleur qui est toujours exécuté en dernier
   */
  private async executeInParallel(): Promise<void> {
    // Séparer l'assembleur des autres agents
    const assemblerIndex = this.config.agentsToRun.indexOf('assembler');
    const hasAssembler = assemblerIndex !== -1;
    
    let agentsToRunInParallel = [...this.config.agentsToRun];
    if (hasAssembler) {
      agentsToRunInParallel.splice(assemblerIndex, 1);
    }
    
    // Exécuter tous les agents en parallèle sauf l'assembleur
    const promises = agentsToRunInParallel.map(agentType => this.executeAgent(agentType));
    const results = await Promise.all(promises);
    this.results.push(...results);
    
    // Vérifier si tous les agents ont réussi
    const allSucceeded = results.every(result => result.success);
    
    // Exécuter l'assembleur uniquement si tous les autres agents ont réussi
    if (hasAssembler && allSucceeded) {
      const assemblerResult = await this.executeAgent('assembler');
      this.results.push(assemblerResult);
      
      if (!assemblerResult.success) {
        throw new Error(`L'agent assembleur a échoué. Le processus est incomplet.`);
      }
    } else if (hasAssembler) {
      console.error(`Un ou plusieurs agents ont échoué. L'assembleur ne sera pas exécuté.`);
    }
  }

  /**
   * Exécute le processus d'audit complet
   */
  public async execute(): Promise<AgentExecutionResult[]> {
    this.startTime = Date.now();
    console.log(`🚀 Démarrage de l'audit pour ${this.config.phpFilePath}`);
    
    try {
      // Préparation
      await this.validateFile();
      await this.ensureOutputDirectory();
      await this.initializeAuditSections();
      
      // Exécution des agents
      if (this.config.parallel) {
        await this.executeInParallel();
      } else {
        await this.executeSerially();
      }
      
      // Calculer le temps total
      const totalTime = Date.now() - this.startTime;
      console.log(`✅ Audit terminé en ${totalTime}ms`);
      
      // Hook de fin de processus
      if (this.config.hooks?.onComplete) {
        await this.config.hooks.onComplete();
      }
      
      return this.results;
    } catch (error) {
      const totalTime = Date.now() - this.startTime;
      console.error(`❌ Audit échoué après ${totalTime}ms: ${error.message}`);
      throw error;
    }
  }

  /**
   * Génère un rapport d'exécution
   */
  public generateExecutionReport(): string {
    const totalTime = Date.now() - this.startTime;
    const successCount = this.results.filter(r => r.success).length;
    const failCount = this.results.filter(r => !r.success).length;
    
    let report = `# Rapport d'exécution des agents\n\n`;
    report += `- **Fichier**: ${this.config.phpFilePath}\n`;
    report += `- **Date**: ${new Date().toLocaleString()}\n`;
    report += `- **Durée totale**: ${totalTime}ms\n`;
    report += `- **Agents exécutés**: ${this.results.length} (${successCount} réussis, ${failCount} échoués)\n\n`;
    
    report += `## Détail des exécutions\n\n`;
    report += `| Agent | Statut | Durée (ms) | Erreur |\n`;
    report += `|-------|--------|------------|--------|\n`;
    
    this.results.forEach(result => {
      const status = result.success ? '✅ Réussi' : '❌ Échoué';
      const error = result.error ? result.error.message : '';
      report += `| ${result.agentName} | ${status} | ${result.executionTime} | ${error} |\n`;
    });
    
    return report;
  }

  /**
   * Enregistre le rapport d'exécution dans un fichier
   */
  public async saveExecutionReport(): Promise<string> {
    const baseFilename = path.basename(this.config.phpFilePath);
    const reportPath = path.join(this.config.outputDir, `${baseFilename}.execution_report.md`);
    
    const report = this.generateExecutionReport();
    await fs.writeFile(reportPath, report, 'utf8');
    
    console.log(`📝 Rapport d'exécution enregistré: ${reportPath}`);
    return reportPath;
  }
}

/**
 * Point d'entrée en ligne de commande
 */
async function main() {
  // Analyser les arguments
  const args = process.argv.slice(2);
  if (args.length < 1) {
    console.error('Usage: ts-node coordinator-agent.ts <chemin-fichier-php> [options]');
    console.error('Options:');
    console.error('  --parallel       Exécuter les agents en parallèle');
    console.error('  --force          Forcer la réexécution même si déjà audité');
    console.error('  --agents <liste> Liste d\'agents à exécuter (séparés par des virgules)');
    console.error('  --output <dir>   Dossier de sortie des rapports');
    process.exit(1);
  }

  const phpFilePath = args[0];
  const parallel = args.includes('--parallel');
  const forceRerun = args.includes('--force');
  let agentsToRun;
  let outputDir;

  // Extraire la liste des agents
  const agentsIndex = args.indexOf('--agents');
  if (agentsIndex !== -1 && agentsIndex < args.length - 1) {
    agentsToRun = args[agentsIndex + 1].split(',') as CoordinatorConfig['agentsToRun'];
  }

  // Extraire le dossier de sortie
  const outputIndex = args.indexOf('--output');
  if (outputIndex !== -1 && outputIndex < args.length - 1) {
    outputDir = args[outputIndex + 1];
  }

  try {
    const coordinator = new CoordinatorAgent({
      phpFilePath,
      outputDir,
      agentsToRun,
      parallel,
      forceRerun,
      hooks: {
        beforeAgent: async (agentName) => {
          console.log(`⏳ Préparation de l'agent ${agentName}...`);
        },
        afterAgent: async (agentName) => {
          console.log(`🏁 Finalisation de l'agent ${agentName}...`);
        },
        onError: async (agentName, error) => {
          console.error(`🚨 Erreur avec l'agent ${agentName}: ${error.message}`);
        },
        onComplete: async () => {
          console.log(`🎉 Tous les agents ont terminé leur exécution.`);
        }
      }
    });

    await coordinator.execute();
    await coordinator.saveExecutionReport();
  } catch (error) {
    console.error(`Erreur fatale: ${error.message}`);
    process.exit(1);
  }
}

// Exécuter le script si appelé directement
if (require.main === module) {
  main();
}
