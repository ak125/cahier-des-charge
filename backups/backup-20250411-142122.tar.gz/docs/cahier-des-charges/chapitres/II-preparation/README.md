# Chapitre II-preparation

## Contenu du chapitre


- [04-checklist-pre-migration](./04-checklist-pre-migration.md) - 
- [05-gel-code-legacy](./05-gel-code-legacy.md) - 41-gel-code-legacy
- [06-gel-structure-cible](./06-gel-structure-cible.md) - 42-gel-structure-cible
- [07-verification-env-test](./07-verification-env-test.md) - ✅ 2. Vérification et validation de l'environnement de test
- [08-profil-monorepo-reference](./08-profil-monorepo-reference.md) - 45-profil-monorepo-reference
