# 42-gel-structure-cible

Ce document fait partie du cahier des charges de migration.

