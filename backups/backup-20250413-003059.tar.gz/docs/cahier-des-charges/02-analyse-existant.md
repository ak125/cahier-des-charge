# Analyse de l'existant

## Structure de l'application actuelle

L'application PHP actuelle est organisée selon une structure non-standard:

