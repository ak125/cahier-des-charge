# Chapitre VI-securite

## Contenu du chapitre


- [17-checklist-avant-lancement](./17-checklist-avant-lancement.md) - Checklist d'avant lancement – Migration IA sécurisée
- [18-checklist-bonus-securite](./18-checklist-bonus-securite.md) - 46-checklist-bonus-securite
