#!/bin/bash

# Script de vérification de la réorganisation du projet
# Date: 11 avril 2025
# Ce script vérifie que la réorganisation effectuée par organize-project.sh s'est bien déroulée
# et propose des fonctionnalités supplémentaires pour aider à finaliser la migration

# Définition des couleurs pour les messages
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Dossiers à ignorer dans les analyses
IGNORE_DIRS="node_modules|dist|.git|.cache|.vscode|coverage|build"

# Fonction pour afficher les messages d'information
info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Fonction pour afficher les messages de succès
success() {
    echo -e "${GREEN}[SUCCÈS]${NC} $1"
}

# Fonction pour afficher les avertissements
warning() {
    echo -e "${YELLOW}[AVERTISSEMENT]${NC} $1"
}

# Fonction pour afficher les erreurs
error() {
    echo -e "${RED}[ERREUR]${NC} $1"
}

# Fonction pour afficher les titres des sections
section() {
    echo -e "\n${MAGENTA}=== $1 ===${NC}"
}

# Fonction pour vérifier l'existence d'un dossier
check_directory() {
    if [ -d "$1" ]; then
        success "Le dossier $1 existe."
        return 0
    else
        error "Le dossier $1 n'existe pas!"
        return 1
    fi
}

# Fonction pour vérifier l'existence d'un fichier
check_file() {
    if [ -f "$1" ]; then
        success "Le fichier $1 existe."
        return 0
    else
        error "Le fichier $1 n'existe pas!"
        return 1
    fi
}

# Fonction pour compter les fichiers dans un dossier (récursivement)
count_files() {
    find "$1" -type f | grep -v -E "($IGNORE_DIRS)" | wc -l
}

# Fonction pour vérifier les références de chemins dans les fichiers
check_paths_in_file() {
    local file=$1
    local success=true
    
    if [ ! -f "$file" ]; then
        error "Le fichier $file n'existe pas, impossible de vérifier les références."
        return 1
    fi
    
    info "Vérification des chemins dans $file..."
    
    # Extraire les chemins entre guillemets
    grep -o '"[^"]*"' "$file" | tr -d '"' | grep -E "^(\.|\/).*" | while read -r path; do
        # Vérifier si le chemin est relatif et le convertir en absolu
        if [[ "$path" == ./* ]]; then
            path=$(dirname "$file")/${path:2}
        fi
        
        if [ ! -e "$path" ]; then
            warning "Chemin invalide trouvé dans $file: $path"
            success=false
        fi
    done
    
    if [ "$success" = true ]; then
        success "Tous les chemins dans $file semblent valides."
    fi
}

# Fonction pour générer un rapport de réorganisation
generate_report() {
    local report_file="docs/rapports/reorganisation-$(date +%Y%m%d-%H%M%S).md"
    mkdir -p "docs/rapports"
    
    {
        echo "# Rapport de réorganisation du projet"
        echo "Date: $(date '+%d/%m/%Y %H:%M:%S')"
        echo ""
        echo "## Structure des dossiers"
        echo '```'
        find . -type d -not -path "*/\.*" | grep -v -E "($IGNORE_DIRS)" | sort | sed 's/^/- /'
        echo '```'
        echo ""
        echo "## Statistiques"
        echo "- Nombre total de dossiers: $(find . -type d -not -path "*/\.*" | grep -v -E "($IGNORE_DIRS)" | wc -l)"
        echo "- Nombre total de fichiers: $(find . -type f -not -path "*/\.*" | grep -v -E "($IGNORE_DIRS)" | wc -l)"
        echo ""
        echo "### Répartition par type de fichier"
        echo '```'
        find . -type f -not -path "*/\.*" | grep -v -E "($IGNORE_DIRS)" | grep -o '\.[^.]*$' | sort | uniq -c | sort -nr
        echo '```'
        echo ""
        echo "### Répartition par dossier"
        for dir in */; do
            if ! echo "$dir" | grep -q -E "($IGNORE_DIRS)"; then
                echo "- $dir: $(count_files "$dir") fichiers"
            fi
        done
    } > "$report_file"
    
    success "Rapport généré: $report_file"
}

# Fonction pour proposer des actions de nettoyage
suggest_cleanup() {
    section "Suggestions de nettoyage"
    
    # Vérifier les fichiers potentiellement doublons
    info "Recherche de fichiers potentiellement doublons..."
    find . -type f -not -path "*/\.*" -not -path "*/backups/*" -not -path "*/node_modules/*" -exec md5sum {} \; | sort | uniq -w32 -d
    
    # Vérifier les fichiers de sauvegarde
    info "Recherche de fichiers de sauvegarde pouvant être nettoyés..."
    find . -type f -name "*.bak*" -o -name "*.backup" -o -name "*~" | sort
    
    # Vérifier les dossiers vides
    info "Dossiers vides pouvant être supprimés..."
    find . -type d -empty -not -path "*/\.*" -not -path "*/node_modules/*"
}

# Fonction pour vérifier les mises à jour de configuration nécessaires
check_config_updates() {
    section "Vérification des configurations"
    
    if [ -f "migration-config.json" ]; then
        info "Analyse de migration-config.json..."
        check_paths_in_file "migration-config.json"
    else
        warning "Fichier migration-config.json non trouvé."
    fi
    
    # Vérifier les autres fichiers de configuration
    for config_file in config/*.json config/*.yml docker-compose*.yml; do
        if [ -f "$config_file" ]; then
            info "Analyse de $config_file..."
            check_paths_in_file "$config_file"
        fi
    done
}

# Fonction pour proposer des mises à jour automatiques
suggest_updates() {
    section "Suggestions de mises à jour"
    
    # Chercher les fichiers JS/TS qui peuvent contenir des imports à mettre à jour
    info "Fichiers JS/TS pouvant nécessiter des mises à jour d'imports..."
    grep -r "import.*from" --include="*.js" --include="*.ts" . | grep -v "node_modules" | wc -l
    
    if [ -f "fix-agent-imports.sh" ]; then
        info "Le script fix-agent-imports.sh est disponible pour mettre à jour les imports des agents."
        info "Exécutez './fix-agent-imports.sh' pour appliquer automatiquement les corrections."
    fi
}

# Menu principal du script
show_menu() {
    clear
    section "VÉRIFICATION DE LA RÉORGANISATION DU PROJET"
    echo -e "${CYAN}1.${NC} Vérifier la structure des dossiers"
    echo -e "${CYAN}2.${NC} Vérifier les fichiers de configuration"
    echo -e "${CYAN}3.${NC} Générer un rapport de réorganisation"
    echo -e "${CYAN}4.${NC} Afficher les suggestions de nettoyage"
    echo -e "${CYAN}5.${NC} Vérifier les mises à jour nécessaires"
    echo -e "${CYAN}6.${NC} Exécuter toutes les vérifications"
    echo -e "${CYAN}0.${NC} Quitter"
    echo ""
    read -p "Choisissez une option: " choice
    
    case $choice in
        1) check_structure;;
        2) check_config_updates;;
        3) generate_report;;
        4) suggest_cleanup;;
        5) suggest_updates;;
        6) run_all_checks;;
        0) exit 0;;
        *) warning "Option invalide, veuillez réessayer."; sleep 1; show_menu;;
    esac
    
    echo ""
    read -p "Appuyez sur Entrée pour revenir au menu..." 
    show_menu
}

# Fonction pour vérifier la structure des dossiers
check_structure() {
    section "Vérification de la structure des dossiers"
    
    # Vérifier les dossiers principaux
    directories=(
        "docs/cahier-des-charges"
        "docs/specifications"
        "scripts/migration"
        "scripts/verification"
        "scripts/generation"
        "scripts/maintenance"
        "agents/core"
        "agents/analysis"
        "agents/migration"
        "agents/quality"
        "backups"
    )
    
    success_count=0
    total=${#directories[@]}
    
    for dir in "${directories[@]}"; do
        if check_directory "$dir"; then
            ((success_count++))
        fi
    done
    
    echo ""
    if [ $success_count -eq $total ]; then
        success "Tous les dossiers ont été créés correctement ($success_count/$total)"
    else
        warning "Certains dossiers sont manquants (seulement $success_count/$total existant)"
    fi
}

# Fonction pour exécuter toutes les vérifications
run_all_checks() {
    section "EXÉCUTION DE TOUTES LES VÉRIFICATIONS"
    
    check_structure
    check_config_updates
    suggest_cleanup
    suggest_updates
    generate_report
    
    success "Toutes les vérifications ont été effectuées."
}

# Point d'entrée du script
if [ "$1" == "--auto" ]; then
    # Mode automatique (exécute toutes les vérifications sans menu)
    run_all_checks
else
    # Mode interactif avec menu
    show_menu
fi