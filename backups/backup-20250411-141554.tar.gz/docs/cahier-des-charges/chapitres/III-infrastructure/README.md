# Chapitre III-infrastructure

## Contenu du chapitre


- [09-socle-ia-analyse-migration](./09-socle-ia-analyse-migration.md) - 43-socle-ia-analyse-migration
- [10-procedure-installation-pipeline](./10-procedure-installation-pipeline.md) - 39-procedure-installation-pipeline
- [11-command-center](./11-command-center.md) - 34-command-center
